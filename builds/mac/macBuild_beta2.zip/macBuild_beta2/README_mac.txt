Please follow the instructions IF the app cannot open
 

1. Go in Terminal

2. Type in the following two commands, one by one.

First type "cd ~/Downloads/macBuild_beta2/macBuild_beta2.app/Contents/MacOS/", note if you moved the file from the Downloads folder, please change the path accordingly.

Then type chmod -R 777 Random_motion_yes

3. Now you should be able to run the game no problems, feel free the move the file out of the downloads folder if you want.



The commands in step three gives the app the permission to execute on MacOS. Because this app was built on a windows system, it cannot pre-set the run permission 
-for MacOS or Linux, therefore you might need to run the command to give it permission. If you have any questions, feel free to contact me at ytc344@nyu.edu

