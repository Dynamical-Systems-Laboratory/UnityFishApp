To use the app, simply double click to open the executable file. 
If you have any questions or suggestions, please email me at ytc344@nyu.edu